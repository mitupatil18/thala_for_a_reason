#include <iostream>
#include <fstream>
#include <vector>
#include <cmath>
#include <sstream>

using namespace std;

void expandCluster(int pointIndex, const vector<int>& neighbors, vector<int>& clusterAssignments,
                   int clusterId, const vector<double>& data, double epsilon, int minPts);

vector<int> getNeighbors(int index, const vector<double>& data, double epsilon);

int main() {
    string csvFile = "data.csv";
    vector<double> weightValues;
    string line;

    
    ifstream file(csvFile);
    if (!file.is_open()) {
        cerr << "Unable to open file" << endl;
        return 1;
    }
    getline(file, line);
    while (getline(file, line)) {
        stringstream ss(line);
        string weightStr;
        getline(ss, weightStr, ',');
        weightValues.push_back(stod(weightStr));
    }
    file.close();

    
    double epsilon;
    int minPts;
    cout << "Enter epsilon (ε): ";
    cin >> epsilon;
    cout << "Enter minimum points (minPts): ";
    cin >> minPts;

    vector<int> clusterAssignments(weightValues.size(), -1);
    int clusterId = 0;

 
    for (size_t i = 0; i < weightValues.size(); ++i) {
        if (clusterAssignments[i] == -1) { 
            vector<int> neighbors = getNeighbors(i, weightValues, epsilon);

            if (neighbors.size() < minPts) {
                clusterAssignments[i] = -1;  
            } else {
                ++clusterId;
                expandCluster(i, neighbors, clusterAssignments, clusterId, weightValues, epsilon, minPts);
            }
        }
    }

 
    cout << "Results:" << endl;
    for (size_t i = 0; i < weightValues.size(); ++i) {
        if (clusterAssignments[i] == -1) {
            cout << "Value: " << weightValues[i] << " -> Noise" << endl;
        } else {
            cout << "Value: " << weightValues[i] << " -> Cluster " << clusterAssignments[i] << endl;
        }
    }

    return 0;
}

vector<int> getNeighbors(int index, const vector<double>& data, double epsilon) {
    vector<int> neighbors;
    for (size_t j = 0; j < data.size(); ++j) {
        if (fabs(data[index] - data[j]) <= epsilon) {
            neighbors.push_back(j);
        }
    }
    return neighbors;
}

void expandCluster(int pointIndex, const vector<int>& neighbors, vector<int>& clusterAssignments,
                   int clusterId, const vector<double>& data, double epsilon, int minPts) {
    clusterAssignments[pointIndex] = clusterId;

    vector<int> expandedNeighbors = neighbors;

    for (size_t i = 0; i < expandedNeighbors.size(); ++i) {
        int neighborIndex = expandedNeighbors[i];

        if (clusterAssignments[neighborIndex] == -1) {
            clusterAssignments[neighborIndex] = clusterId;
        }

        if (clusterAssignments[neighborIndex] == 0) {
            clusterAssignments[neighborIndex] = clusterId;

            vector<int> neighborNeighbors = getNeighbors(neighborIndex, data, epsilon);
            if (neighborNeighbors.size() >= minPts) {
                expandedNeighbors.insert(expandedNeighbors.end(), neighborNeighbors.begin(), neighborNeighbors.end());
            }
        }
    }
}