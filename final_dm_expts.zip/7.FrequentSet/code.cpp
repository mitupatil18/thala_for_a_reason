#include <iostream>
#include <fstream>
#include <sstream>
#include <vector>
#include <set>
#include <map>
#include <string>
#include <algorithm>
#include <iterator>

std::map<std::set<std::string>, int> generate_itemset_support_count(int k, const std::vector<std::set<std::string>>& transactions, int min_support) {
    std::map<std::set<std::string>, int> itemset_counts;

    for (const auto& transaction : transactions) {
        std::vector<std::string> items(transaction.begin(), transaction.end());
        std::sort(items.begin(), items.end());

        std::vector<bool> v(items.size());
        std::fill(v.begin(), v.begin() + k, true);
        do {
            std::set<std::string> itemset;
            for (size_t i = 0; i < items.size(); ++i) {
                if (v[i]) {
                    itemset.insert(items[i]);
                }
            }
            itemset_counts[itemset]++;
        } while (std::prev_permutation(v.begin(), v.end()));
    }

    for (auto it = itemset_counts.begin(); it != itemset_counts.end();) {
        if (it->second < min_support) {
            it = itemset_counts.erase(it);
        } else {
            ++it;
        }
    }

    return itemset_counts;
}

std::vector<std::set<std::string>> read_transactions_from_csv(const std::string& file_path) {
    std::ifstream infile(file_path);
    std::vector<std::set<std::string>> transactions;
    std::string line;

    bool is_first_row = true; 

    while (std::getline(infile, line)) {
        if (is_first_row) {
            is_first_row = false;
            continue;
        }

        std::set<std::string> transaction;
        std::stringstream ss(line);
        std::string item;

        bool is_first_column = true; 
        while (std::getline(ss, item, ',')) {
            if (is_first_column) {
                is_first_column = false; 
                continue;
            }
            if (!item.empty()) { 
                transaction.insert(item);
            }
        }

        transactions.push_back(transaction);
    }

    return transactions;
}

int main() {
    std::string file_path;
    int min_support;

    std::cout << "Enter the path to your CSV file: ";
    std::getline(std::cin, file_path);
    std::cout << "Enter the minimum support threshold: ";
    std::cin >> min_support;

    auto transactions = read_transactions_from_csv(file_path);

    std::set<std::string> unique_items;
    for (const auto& transaction : transactions) {
        unique_items.insert(transaction.begin(), transaction.end());
    }

    std::ofstream outFile("itemset_support_counts.txt");
    outFile << "Itemset Support Counts (min support = " << min_support << "):\n";

    for (int k = 1; k <= unique_items.size(); ++k) {
        auto itemset_counts = generate_itemset_support_count(k, transactions, min_support);

        if (!itemset_counts.empty()) {
            outFile << "\nItemsets of size " << k << ":\n";
            for (const auto& pair : itemset_counts) {
                const auto& itemset = pair.first;
                int count = pair.second;
                outFile << "{ ";
                for (const auto& item : itemset) {
                    outFile << item << " ";
                }
                outFile << "}, Support Count: " << count << "\n";
            }
        } else {
            outFile << "\nNo itemsets of size " << k << " meet the minimum support threshold.\n";
            break;
        }
    }

    outFile.close();
    std::cout << "Itemset support counts have been written to itemset_support_counts.txt\n";

    return 0;
}
