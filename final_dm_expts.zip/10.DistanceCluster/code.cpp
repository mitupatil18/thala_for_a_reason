#include <iostream>
#include <fstream>
#include <vector>
#include <cmath>
#include <limits>

using namespace std;

double calculateMean(const vector<double>& points) {
    double sum = 0;
    for (double point : points) {
        sum += point;
    }
    return sum / points.size();
}

int findNearestCentroid(double value, const vector<double>& centroids) {
    int nearestCentroidIndex = 0;
    double minDistance = abs(value - centroids[0]);

    for (int i = 1; i < centroids.size(); i++) {
        double distance = abs(value - centroids[i]);
        if (distance < minDistance) {
            minDistance = distance;
            nearestCentroidIndex = i;
        }
    }
    return nearestCentroidIndex;
}

vector<double> getClusterPoints(const vector<double>& data, const vector<int>& assignments, int clusterIndex) {
    vector<double> clusterPoints;
    for (int i = 0; i < data.size(); i++) {
        if (assignments[i] == clusterIndex) {
            clusterPoints.push_back(data[i]);
        }
    }
    return clusterPoints;
}

int main() {
    string csvFile = "data.csv";
    string outputFile = "cluster_results.csv";
    vector<double> weightValues;
    ifstream file(csvFile);

    if (!file.is_open()) {
        cerr << "Error opening file." << endl;
        return 1;
    }

    string line;
    getline(file, line); 

    while (getline(file, line)) {
        size_t comma = line.find(",");
        double weight = stod(line.substr(0, comma));  
        weightValues.push_back(weight);
    }
    file.close();

    int k;
    cout << "Enter the number of clusters (K): ";
    cin >> k;

    vector<double> centroids(k);
    for (int i = 0; i < k; i++) {
        cout << "Enter initial centroid " << (i + 1) << ": ";
        cin >> centroids[i];
    }

    vector<int> clusterAssignments(weightValues.size());
    bool centroidsChanged = true;
    int iterations = 0;

    ofstream outfile(outputFile);
    if (!outfile.is_open()) {
        cerr << "Error opening output file." << endl;
        return 1;
    }

    outfile << "Iteration,Value,Cluster\n";

    while (centroidsChanged && iterations < 100) {
        iterations++;
        centroidsChanged = false;

        for (int i = 0; i < weightValues.size(); i++) {
            int nearestCentroidIndex = findNearestCentroid(weightValues[i], centroids);
            clusterAssignments[i] = nearestCentroidIndex;
            outfile << iterations << "," << weightValues[i] << "," << nearestCentroidIndex << "\n";
        }

        for (int i = 0; i < k; i++) {
            vector<double> clusterPoints = getClusterPoints(weightValues, clusterAssignments, i);
            if (!clusterPoints.empty()) {
                double newCentroid = calculateMean(clusterPoints);
                if (abs(centroids[i] - newCentroid) > 1e-4) {
                    centroids[i] = newCentroid;
                    centroidsChanged = true;
                }
            }
        }

        cout << "Iteration " << iterations << ": Centroids = ";
        for (double centroid : centroids) {
            cout << centroid << " ";
        }
        cout << endl;
    }

    cout << "Final Cluster Assignments:" << endl;
    for (int i = 0; i < weightValues.size(); i++) {
        cout << "Value: " << weightValues[i] << " -> Cluster: " << clusterAssignments[i] << endl;
    }

    outfile.close();
    cout << "Cluster results saved to " << outputFile << endl;

    return 0;
}
