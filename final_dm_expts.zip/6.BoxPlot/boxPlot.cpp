#include <iostream>
#include <fstream>
#include <sstream>
#include <vector>
#include <algorithm>
#include <string>
#include <iomanip>

using namespace std;

vector<double> readColumnDataFromCSV(const string& filePath, const string& columnName) {
    vector<double> data;
    ifstream file(filePath);
    if (!file.is_open()) {
        throw runtime_error("Error: Could not open the file.");
    }

    string line;
    getline(file, line);  
    string header = line;

    if (header.find(columnName) == string::npos) {
        throw invalid_argument("Column name not found in the CSV file.");
    }

    while (getline(file, line)) {
        try {
            double value = stod(line);
            data.push_back(value);
        } catch (const exception& e) {
            
        }
    }

    file.close();
    return data;
}

vector<double> calculateBoxPlotStatistics(vector<double>& sortedData) {
    int n = sortedData.size();
    double Q1, Q2, Q3;

    if (n % 2 == 0) {
        Q2 = (sortedData[n / 2 - 1] + sortedData[n / 2]) / 2.0;
        vector<double> lowerHalf(sortedData.begin(), sortedData.begin() + n / 2);
        vector<double> upperHalf(sortedData.begin() + n / 2, sortedData.end());

        if (lowerHalf.size() % 2 == 0) {
            Q1 = (lowerHalf[lowerHalf.size() / 2 - 1] + lowerHalf[lowerHalf.size() / 2]) / 2.0;
        } else {
            Q1 = lowerHalf[lowerHalf.size() / 2];
        }

        if (upperHalf.size() % 2 == 0) {
            Q3 = (upperHalf[upperHalf.size() / 2 - 1] + upperHalf[upperHalf.size() / 2]) / 2.0;
        } else {
            Q3 = upperHalf[upperHalf.size() / 2];
        }
    } else {
        Q2 = sortedData[n / 2];
        vector<double> lowerHalf(sortedData.begin(), sortedData.begin() + n / 2);
        vector<double> upperHalf(sortedData.begin() + n / 2 + 1, sortedData.end());

        if (lowerHalf.size() % 2 == 0) {
            Q1 = (lowerHalf[lowerHalf.size() / 2 - 1] + lowerHalf[lowerHalf.size() / 2]) / 2.0;
        } else {
            Q1 = lowerHalf[lowerHalf.size() / 2];
        }

        if (upperHalf.size() % 2 == 0) {
            Q3 = (upperHalf[upperHalf.size() / 2 - 1] + upperHalf[upperHalf.size() / 2]) / 2.0;
        } else {
            Q3 = upperHalf[upperHalf.size() / 2];
        }
    }

    return { Q1, Q2, Q3 };
}

int main() {
    string filePath, columnName;
    cout << "Enter file path: ";
    cin >> filePath;
    cout << "Enter column name (e.g., Marks): ";
    cin >> columnName;

    try {
        vector<double> data = readColumnDataFromCSV(filePath, columnName);

        if (data.empty()) {
            cout << "No valid data found in the specified column." << endl;
            return 0;
        }

        sort(data.begin(), data.end());

        vector<double> boxPlotStats = calculateBoxPlotStatistics(data);
        double Q1 = boxPlotStats[0];
        double Q2 = boxPlotStats[1];
        double Q3 = boxPlotStats[2];
        double IQR = Q3 - Q1;

        double lowerWhisker = Q1 - 1.5 * IQR;
        double upperWhisker = Q3 + 1.5 * IQR;

        vector<double> outliers;
        for (double value : data) {
            if (value < lowerWhisker || value > upperWhisker) {
                outliers.push_back(value);
            }
        }

        double minimum = *min_element(data.begin(), data.end());
        double maximum = *max_element(data.begin(), data.end());

        cout << fixed << setprecision(2);
        cout << "Minimum: " << minimum << endl;
        cout << "Q1: " << Q1 << endl;
        cout << "Median (Q2): " << Q2 << endl;
        cout << "Q3: " << Q3 << endl;
        cout << "IQR: " << IQR << endl;
        cout << "Lower Whisker: " << lowerWhisker << endl;
        cout << "Upper Whisker: " << upperWhisker << endl;
        cout << "Maximum: " << maximum << endl;

        if (outliers.empty()) {
            cout << "Outliers: None" << endl;
        } else {
            cout << "Outliers: ";
            for (double outlier : outliers) {
                cout << outlier << " ";
            }
            cout << endl;
        }

    } catch (const exception& e) {
        cerr << e.what() << endl;
    }

    return 0;
}
